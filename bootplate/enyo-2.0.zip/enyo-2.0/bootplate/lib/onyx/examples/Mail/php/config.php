﻿<?php

$mail = "{imap.1and1.com:143}";
$user = "test@turboajax.com";
$pass = "testtest";

?>