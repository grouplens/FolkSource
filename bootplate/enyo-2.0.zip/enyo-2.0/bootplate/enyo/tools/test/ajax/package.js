enyo.depends(
	"$lib/extra/test"
);
