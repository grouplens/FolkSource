enyo.depends(
	"AjaxTest.js",
	"JsonpTest.js",
	"WebServiceTest.js"
);
