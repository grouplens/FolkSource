bootplate
=========

Application template for packaged Enyo

Refer to the [Wiki](https://github.com/enyojs/enyo/wiki/Bootplate) for how to get started.
